class CascadeSelect {
    constructor(select) {
        this.originalSelect = select;
    }

    init() {
        this.collectOptions(); // adatok kigyüjtése
        this.createSelects();  // select-ek létrehozása + 1. select feltöltése
        this.populate();       // 2. select feltöltése
        this.groupSelect.addEventListener('change', () => {
            this.populate();   // 2. select feltöltése, ha change van az 1. selectben
        });
    }
}

const cascadeSelect = new CascadeSelect(
    document.querySelector('select')
);
cascadeSelect.init();